const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DfNZdwKz.js","assets/index-D1ZBgHxV.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-Bm0UWI-c.js";import{r as o}from"./index-D1ZBgHxV.js";import"./vue-Ce9XrPCw.js";import"./quasar-Dpth6S10.js";const n=o("Preferences",{web:()=>r(()=>import("./web-DfNZdwKz.js"),__vite__mapDeps([0,1])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
//# sourceMappingURL=index-DRGm4rC0.js.map
