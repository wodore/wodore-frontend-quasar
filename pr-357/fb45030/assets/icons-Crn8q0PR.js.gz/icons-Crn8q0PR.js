import{b as r}from"./quasar-B261Aapr.js";import"./vue-8ve7ahA3.js";const a=r(({app:o})=>{o.config.globalProperties.$q.iconMapFn=t=>{if(t.startsWith("wd-")===!0)return{cls:"wd "+t}}});export{a as default};
//# sourceMappingURL=icons-Crn8q0PR.js.map
